package TataAigpackage;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.security.PublicKey;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.google.common.io.Files;



public class tataAigTest {
	WebDriver driver;
@BeforeMethod
public void preCondition() 
{

	
		//launch chrome browser
		System.setProperty("webdriver.chrome.driver", "./exefiles/chromedriver.exe");
		 driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
	//	navigate to url
		driver.get("https://www.amazon.in/");
		//Thread.sleep(5000);
}
		//added delay to solve captcha manually because in automation this is not a good practice 
		//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 //Thread.sleep(5000);
	@Test(priority=1)
public void searchfromsearchToPlaceOrder()
{
		//1-search product>Searching for a product: 
	 driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys("Mamy Poko Pant m size");
	 driver.findElement(By.id("nav-search-submit-button")).click();
	 //verify search product
	 String ActualText = driver.findElement(By.xpath("//*[@id=\"search\"]/span[2]/div/h1/div/div[1]/div/div/span[3]")).getText();
	 System.out.println(ActualText);
	 String ExpectedText = "\"Mamy Poko Pant m size\"" ;
	 Assert.assertEquals(ActualText,ExpectedText);
	 Reporter.log("ExpectedText",true);

	 //2-Filtering the search results: 
	 driver.findElement(By.xpath("//*[@id=\"p_36/2485524031\"]/span/a/span")).click();
	 TakesScreenshot ts = (TakesScreenshot)driver;
	   File srcfile = ts.getScreenshotAs(OutputType.FILE);
	       File destfile = new File("./Screenshot/firstshot.png");
	       try
	       {
	    	   Files.copy(srcfile,destfile);
	       }
	       catch(IOException e)
	       {
	    	   e.printStackTrace();
	       }
	
	 //3-Adding a product to the shopping cart: 
	driver.findElement(By.linkText("MamyPoko Pants Standard Baby Diapers, Medium (M), 32 Count, 7-12 kg")).click();
	//switch to window 
	 Set<String> allWindowHandles = driver. getWindowHandles();
	 System.out.println("Total Tabs:"+ allWindowHandles.size());
	Iterator<String> itr= allWindowHandles.iterator();
	String ParentId =itr.next();
	System.out.println("Parent Tabs:"+ ParentId);
	String ChildId =itr.next();
	System.out.println("Child Tabs:"+ ChildId);
	driver.switchTo().window(ChildId);
	driver.findElement(By.xpath("//*[@id=\"add-to-cart-button\"]")).click();
	
//4.Proceeding to checkout: 
	driver.findElement(By.xpath("//*[@id=\"sw-gtc\"]/span/a")).click();
	//verify search product
		
	String Actualaddedproduct = driver.findElement(By.linkText("MamyPoko Pants Standard Baby Diapers, Medium (M), 32 Count, 7-12 kg")).getText();	 
	System.out.println(Actualaddedproduct);
		 String Expectedaddedproduct = "MamyPoko Pants Standard Baby Diapers, Medium (M), 32 Count, 7-12 kg" ;
		 Assert.assertEquals(Actualaddedproduct,Expectedaddedproduct);
		 Reporter.log("Expectedaddedproduct",true);
		 driver.findElement(By.xpath("//*[@id=\"sc-buy-box-ptc-button\"]/span/input")).click();
		 driver.findElement(By.xpath("//input[@id=\"ap_email\"]")).sendKeys("pandeysoni2505@gmail.com");
		 driver.findElement(By.xpath("//*[@id=\"continue\"]")).click();
		 driver.findElement(By.xpath("//*[@id=\"ap_password\"]")).sendKeys("Soni@2325");
		 driver.findElement(By.xpath("//*[@id='signInSubmit']")).click();
	
	//5-Filling out the checkout form: 
			 
	driver.findElement(By.xpath("//*[@id=\"add-new-address-popover-link\"]")).click();
	driver.findElement(By.xpath("//*[@id=\"address-ui-widgets-enterAddressFullName\"]")).sendKeys("Soni Pandey");
	driver.findElement(By.xpath("//*[@id=\"address-ui-widgets-enterAddressPhoneNumber\"]")).sendKeys("9667223693");	
	driver.findElement(By.xpath("//*[@id=\"address-ui-widgets-enterAddressPostalCode\"]")).sendKeys("122001");
	driver.findElement(By.xpath("//*[@id=\"address-ui-widgets-enterAddressLine1\"]")).sendKeys("H.No-359");
	driver.findElement(By.xpath("//*[@id=\"address-ui-widgets-enterAddressLine2\"]")).sendKeys("Sec-10");
	driver.findElement(By.xpath("//*[@id=\"address-ui-widgets-landmark\"]")).sendKeys("City Bus Depo");
	driver.findElement(By.xpath("//*[@id=\"address-ui-widgets-enterAddressCity\"]")).sendKeys("Gurgaon");
		 
//select state
	driver.findElement(By.xpath("//*[@id=\"address-ui-widgets-enterAddressStateOrRegion\"]")).sendKeys("HARYANA");
 //submit the form
 driver.findElement(By.xpath("//*[@id=\"address-ui-widgets-form-submit-button\"]/span/input")).click();
 
 //place your order
 //driver.findElement(By.xpath("//*[@id=\"bottomSubmitOrderButtonId\"]/span/input")).click();
 //Verify checkout
 String ActualCheckOut = driver.findElement(By.xpath("//*[@id=\"header\"]/div/div[3]/h1")).getText();
 System.out.println(ActualCheckOut);
 String ExpectedCheckOut = "Checkout" ;
 Assert.assertEquals(ActualCheckOut,ExpectedCheckOut);
 Reporter.log("ExpectedCheckOut",true);
	}
 
	}
	